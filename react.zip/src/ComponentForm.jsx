const ComponentForm = () => {
    return (
        <form action="UserInfo">
            <label>Name</label>
            <input type="text" />
            <br />
            <label>Email</label>
            <input type="text" />
            <br />
            <label>Password</label>
            <input type="text" />
            <br />
            <button type="submit">Submit</button>
        </form>
    );
}

export default ComponentForm;