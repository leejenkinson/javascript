const movie = require("../db");

const router = require("express").Router();


// fetch data from url 4494/ and send result as hello my name...
router.get("/", (req, res) => {
    res.send("Hello my name is !");
});


router.get("/getAll", (req, res, next) => {
    movie.find()
    .then((results) => res.send(results))
    .catch((err) => next (err));
});
// create a new name and push it to the array
router.post("/create", (req, res, next) => {
    const newMovie = req.body;
    movie.create(newMovie)
    .then ((result) => res.status(201).send(result))
    .catch((err) => next(err));
   });
   
// get names specifically by id (which is a parameter)
router.get("/get/:id", (req, res, next) => {
    const id = req.params.id;
    movie.findById(id)
    .then((result) => res.send(result))
    .catch((err) => next(err));
});

// delete a name by referencing the id and using splice
router.delete("/remove/:id", (req, res, next) => {
    const id = req.params.id;
    movie.findByIdAndDelete(id)
    .then(() => res.status(204).send())
    .cath((err) => next(err));
});


/*

// create multiple names by adding several in Postman body and looping through
router.post("/multipleNames", (req, res) => {
    const name = req.body;

    for (let person of name) {
        names.push(person.name);
    }

    res.send("Multiple names added");
});

// replace a name by using id. In Postman the url must have ?name=whatever the new name is.
// the name added in the url aka query.name is assigned to name (this is the new name)
// oldname is taken from original array at index in the url
// replace old name (name[index]) with new name (name)
router.put("/replace/:index", (req, res) => {
    const name = req.query.name;
    const index = req.params.index;
    const oldName = names[index];
    names[index] = name;
    res.send(`Replaced ${oldName} with ${name}`);
});

*/

module.exports = router;