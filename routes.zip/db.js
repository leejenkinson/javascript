const mongoose = require("mongoose");

mongoose.connect("mongodb://localhost:27017/movies", { useNewUrlParser: true });

const Schema = mongoose.Schema;

const movieSchema = new Schema({
    name: {
        type: String,
        required: true,
        minlength: 1
    },
    description: {
        type: String,
        maxlength: 600
    },
    yearReleased: {
        type: Number,
        min: 1,
        max: 2022
    },
    rating: {
        type: Number,
        min: 0,
        max: 10
    }
});

const movie = mongoose.model("movie", movieSchema);

module.exports = movie;
