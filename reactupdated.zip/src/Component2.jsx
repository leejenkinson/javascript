const Component2 = () => {
    return (
        <h2>Lets start adding some components in here:</h2>
    );
}

export default Component2;