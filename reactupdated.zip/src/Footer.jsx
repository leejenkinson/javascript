const Footer = () => {
    return (
        <> <p>This</p> 
            <p>is</p> 
            <p>the</p> 
            <p>footer</p> 
        </>
    );
}

export default Footer;