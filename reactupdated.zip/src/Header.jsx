const Header = () => {
    return (
        <header>
            <nav className = "navbar navbar-expand-sm">
                <a className = "navbar-brand"
                    href = "www.qa.com"
                    target = "_blank"
                    rel = "noopener noreferrer"
                >
                    <img src="https://i.imgur.com/smguoM3.png" alt="logo" width ="100" />
                </a>
                <a href = "/" className = "navbar-brand">
                    Todo app 
                </a>
            </nav>
        </header>
    );
}

export default Header;