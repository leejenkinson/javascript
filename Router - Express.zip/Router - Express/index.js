// access express
const express = require("express");

//asign the function of express to app
const app = express();

// access body-parser which parses json
const bodyParser = require("body-parser");

// use bodyparser within express
app.use(bodyParser.json());

//import routes into index
const routes = require("./routes/router.js");

app.use(routes);

//logger 
const logIt = (req, res, next) => {
    console.log(new Date());
    next ();
}

app.get("/", logIt, (req, res) => {
    res.send("helllloooooooo!");
});

// shows if server is working
const server = app.listen(4494, () => {
    console.log(`Server started on ${server.address().port}`);
});


// error handling
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
    res.status(err.status).send(err.message);
});