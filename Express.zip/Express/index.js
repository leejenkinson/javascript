// get access to express and asign a constant to it
const express = require("express");
// asign a constant to the function express
const app = express();
// ask express to start listening for traffic on a port. 
// if we console.log we can check its working
const server = app.listen(4494, () => {
    console.log(`Server started on ${server.address().port}`);
});