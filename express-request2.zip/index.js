// access express
const express = require("express");

//asign the function of express to app
const app = express();

// access body-parser which parses json
const bodyParser = require("body-parser");

// use bodyparser within express
app.use(bodyParser.json());

const logIt = (req, res, next) => {
    console.log(new Date());
    next ();
}

app.get("/", logIt, (req, res) => {
    res.send("helllloooooooo!");
});

// shows if server is working
const server = app.listen(4494, () => {
    console.log(`Server started on ${server.address().port}`);
});


// fetch data from url 4494/ and send result as hello my name...
app.get("/", (req, res) => {
    res.send("Hello my name is !");
});

// asign array to names
let names = ['LJ', 'TF', 'MS', 'MP'];

// fetch data and send back all the names in array
app.get("/getAll", (req, res) => {
    res.send(names);
});

// get names specifically by id (which is a parameter)
app.get("/get/:id", (req, res) => {
    res.send(names[req.params.id]);
});

// delete a name by referencing the id and using splice
app.delete("/remove/:id", (req, res) => {
    const id = req.params.id;
    console.log(`Deleted entry with id: ${id}`);
    res.send(names.splice(req.params.id, 1));
});

// create a new name and push it to the array
app.post("/create", (req, res) => {
    const name = req.body.name;
    names.push(name);
    res.send(`${name} added successfully`);
});


// create multiple names by adding several in Postman body and looping through
app.post("/multipleNames", (req, res) => {
    const name = req.body;

    for (let person of name) {
        names.push(person.name);
    }

    res.send("Multiple names added");
});

// replace a name by using id. In Postman the url must have ?name=whatever the new name is.
// the name added in the url aka query.name is assigned to name (this is the new name)
// oldname is taken from original array at index in the url
// replace old name (name[index]) with new name (name)
app.put("/replace/:index", (req, res) => {
    const name = req.query.name;
    const index = req.params.index;
    const oldName = names[index];
    names[index] = name;
    res.send(`Replaced ${oldName} with ${name}`);
});